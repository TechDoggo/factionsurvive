namecount = 'Felipe Coleman.py'
gender = 'male'
huntingskill = '6'
miningskill = '5'
geologyskill = '1'
combatskill = '7'
smithingskill = '9'
##Height: 'tall'
##Hair Color: 'blonde'
##Eye Color 'blue'
##q '
##Is afraid of the underground, and avoids caves.
##Very efficient at forging metal bars.
##Very efficient at defending the camp.
##Very efficient at hunting prey for meat.'
